#include "Includes.h"
unsigned char AMin = 0;
unsigned char Ahour = 6;
unsigned char Min;
unsigned char* hour;
volatile signed char count=0;
unsigned char flag = 0;
unsigned char banner = 0;

sbit DT = P1^2;
//void delay(unsigned int);


void Dial(void) interrupt 0
{
	
	if (DT == 1 && banner==0 )
		{
			count++;	//clockwise rotation
			banner = 1;
		}
	else if (DT == 0 && banner == 0) 
	{
		count--;	//anticlockwise rotation
		banner = 1;
	}

	
}


void Mode(void) interrupt 2
{
	flag = !flag;	// to toggle between alarm mode and normal mode
}



void main(){

	InitLCD();	// Initialize LCD	
   Init_Serial();
   Init_Rtc();
	IE = 0x85; // Enabling external interrupts 0 and 2
	IT0= 1; // Making int0 edge triggered
	IT1 = 1; // Making int1 edge triggered

    DT = 1; //setting as input pin

 //date-month-year,day
Set_Date(11,9,16,Sunday);  // 28:08:2016

	//AM/PM, Hour:Minute:Second	
	
Set_Time(PM,2,18,0);   //08:30:00 AM

	
while(1)
	{
		while (flag == 0)                 //Normal Mode
		{
			if (flag == 1)
				break;

			if (banner == 1)
			{
				
				Min = Get_Mins();
				hour = Get_Hours();
				
				if ( Min >= 59 && count == 1)
				{
					hour[0]++;
					Min = 0;
					banner = 0;
					count = 0;
				}

				else if (Min <=0 && count == -1)
				{
					hour[0]--;
					Min = 59;
					banner = 0;
					count = 0;
				}

				else 
				{
					
					Min += count;
					banner = 0;
					count = 0;
					
				}
				
				Set_Time(PM, hour[0], Min, 0);
				
			}
			DisplayTimeToLCD();
			DisplayDateOnLCD( );
			
		}
		

		while (flag == 1)     // Alarm Mode
		{
			if (flag == 0)
				break;

			if (banner == 1)
			{
				
				if ( AMin >= 59 && count == 1)
				{
					Ahour++;
					AMin = 0;
					banner = 0;
					count = 0;
				}

				else if (Min <=0 && count == -1)
				{
					Ahour--;
					AMin = 59;
					banner = 0;
					count = 0;
				}

				else
				{
					AMin += count;
					banner = 0;
					count = 0;
				}
				
			}
			
			DisplayAlarmToLCD(Ahour,AMin);
			DisplayDateOnLCD( );
			
		}
			
		}
	}
	

		
	



/*void delay(unsigned int d)
{
	unsigned int i;
	for(i=0;i<d;i++);
}*/ 


