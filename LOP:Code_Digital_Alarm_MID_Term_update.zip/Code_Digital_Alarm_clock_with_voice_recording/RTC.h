#ifndef __RTC_H
#define __RTC_H

#define AM 2
#define PM 1


// Define days
#define Monday		1
#define Tuesday		2
#define Wednesday	3	
#define Thursday	4
#define Friday		5
#define Saturday	6
#define Sunday		7





void Init_Rtc(void);
void Write_Rtc_Data(unsigned char,unsigned char);
unsigned char Read_Rtc_Data(unsigned char);
void Set_Date(unsigned char,unsigned char,unsigned char,unsigned char);
void Set_Time(unsigned char,unsigned char,unsigned char,unsigned char);


    unsigned char Get_Secs(void); 	
	unsigned char Get_Mins(void); 
	unsigned char* Get_Hours(void);
	unsigned char Get_Date(void); 
	unsigned char Get_Month(void);
	unsigned char Get_Year(void); 
	unsigned char Get_Day(void);  
 
 #endif
 
 
 