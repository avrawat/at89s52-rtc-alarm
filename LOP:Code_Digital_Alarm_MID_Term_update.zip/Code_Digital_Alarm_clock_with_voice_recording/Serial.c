#include "Includes.h"


// generates a delay of d-micro seconds.

void delay_us(unsigned char d){
	
	d = 256-d;              // Rolls over cycle included
		
	TMOD = 0x02;          //TIMER->0,MODE->2
	TH0=d;               //count
	TR0=1;              // start timer
	while(TF0==0);     // poll TF
	TR0=0;            //stop timer
	TF0=0;           // clear TF
		
}

// delay of m-mili seconds. limited to 50 milis seconds

void delay_ms(unsigned char m){
	
unsigned char i;
m = (m*4);	 

	for(i=0;i<m;i++){  // loops generates delay of m mili seconds
  delay_us(250);   // 250us delay 
	}
}


void init_Serial(){  // call at first in the main.
	// Make RESET,SDA a nd SCL pins input initially
 RESET = Low;
 SCL   = Low;
 SDA   = Low;
}


void Serial_Start(){
	
	//set RESET high throught the communication 
	
	RESET = 1;
	SCL   = 0;
	delay_us(2);
	
}

void Serial_Stop(){

	// TO stop make RESET zero also keep SCL clear when idle.
	
RESET = 0;
SCL = 0;
delay_us(2);
	
}

void Serial_Write_Byte(unsigned char Byte){
	
	unsigned char i;
	SDA = Low;                     //SDA as OUTPUT default it is as output
	
	for(i=0;i<8;i++){
	
		SCL = Low;
		
		if((Byte>>i)& 0x01)  // Place data LSB bit value on SDA pin
			SDA = 1;	// If bit is high, make SDA high
		else				// Data is transferred LSB first
			SDA = 0;	// If bit is low, make SDA low
	
		delay_us(5); 
		SCL = High;     //rising edge so that RTC can read.
		delay_us(5);
		
		}

}	


unsigned char Serial_Read_Byte(void){

unsigned char temp = 0x01,i,RxData=0;
       
	SDA = High;	// Don't Drive SDA (Input pin)
	for(i=0;i<8;i++){
	
	
     
	 SCL = High;        // keep it High
	
	delay_us(5);         
	SCL = Low; 		// Provide falling edge to get data on SDA
    delay_us(5);
		
		
		if (SDA){
		    RxData |=temp;
        }
		
		temp = temp<<1;
	}
	
		return RxData;
	}






















