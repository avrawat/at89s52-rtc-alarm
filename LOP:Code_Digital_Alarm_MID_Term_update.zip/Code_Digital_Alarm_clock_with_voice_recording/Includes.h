#ifndef __INCLUDES_H
#define __INCLUDES_H

#include <reg51.h>
#include "RTC.h"
#include "Serial.h"
#include "LCD.h"
#include <rtx51tny.h>

#endif