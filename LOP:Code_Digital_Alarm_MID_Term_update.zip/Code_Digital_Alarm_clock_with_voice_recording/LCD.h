#ifndef __LCD_H
#define __LCD_H

//*******************
//Pin description
/*
P2.4 to P2.7 is data bus
P1.0 is RS
P1.1 is E
*/
//********************

// Defines Pins
sbit RS = P1^0;
sbit E  = P1^1;

      

// Function Declarations
void DisplayAlarmToLCD(unsigned char,unsigned char);
void InitLCD(void);
void WriteCommandToLCD(int);
void WriteDataToLCD(char);
void ClearLCDScreen(void);
void WriteStringToLCD(const char*);
void DisplayTimeToLCD();
void DisplayDateOnLCD();

#endif