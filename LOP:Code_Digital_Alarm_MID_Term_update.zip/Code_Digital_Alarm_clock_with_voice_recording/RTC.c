#include "Includes.h"



unsigned char temp=0;
unsigned char rtc_hour[3]=0;    // rtc_hour[0]->hour, rtc_hour[1]->12 mode rtc_hour[2]->AM/PM




void Init_Rtc(){

unsigned char ch;

Write_Rtc_Data(0x00,0x8E); // WP disabled
ch = Read_Rtc_Data(0x81);
if(ch&0x80){
Write_Rtc_Data(0x00,0x80); // CH-disabled
}

Write_Rtc_Data(0x80,0x8E); // WP enabled

}



//// First arument is data another is Cmd.
void Write_Rtc_Data(unsigned char dta,unsigned char cmd){

cmd &= 0xFE;  ///ensuring the R/W =0; while writing;
	
Serial_Start();	
	
Serial_Write_Byte(cmd);

Serial_Write_Byte(dta);	

Serial_Stop();	
	
}


void Set_Date(unsigned char dt ,unsigned char mn,unsigned char yr,unsigned char day){

		//convert to BCD
		dt = (((unsigned char)(dt/10))<<4) | ((unsigned char)(dt%10));
		mn = (((unsigned char)(mn/10))<<4) | ((unsigned char)(mn%10));
		yr = (((unsigned char)(yr/10))<<4) | ((unsigned char)(yr%10));
	  day = (((unsigned char)(day/10))<<4) | ((unsigned char)(day%10));
        
      
    Write_Rtc_Data(0x00,0x8E); //WP disabled
       // write data now		
		Write_Rtc_Data(dt,0x86);		//write date
		Write_Rtc_Data(mn,0x88);		//write month
		Write_Rtc_Data(day,0x8A);		//write day
		Write_Rtc_Data(yr,0x8C);	  //write year	

	Write_Rtc_Data(0x80,0x8E); //WP enabled
		
}

	void Set_Time(unsigned char mode,unsigned char h,unsigned char m,unsigned char s)
	{   
		//convert to BCD
		s = (((unsigned char)(s/10))<<4) | ((unsigned char)(s%10));
		m = (((unsigned char)(m/10))<<4) | ((unsigned char)(m%10));
		h = (((unsigned char)(h/10))<<4) | ((unsigned char)(h%10));
    
    //comfig D7 for 12 hour mode and D5 - AM or PM 
     switch(mode)
     {
     	case AM: h |= 0x80; break;    // D7=1,D5=0(AM)
     	case PM: h |= 0xA0; break;   // D7=1,D5=1(PM) 
     	default: break;

     } 
    
    Write_Rtc_Data(0x00,0x8E); //WP disabled
     //Write time in proper format
     Write_Rtc_Data(s,0x80);
     Write_Rtc_Data(m,0x82);
     Write_Rtc_Data(h,0x84);

    Write_Rtc_Data(0x80,0x8E); //WP enabled 

	}

    
    unsigned char Read_Rtc_Data(unsigned char cmd){
		
		cmd &=0xFF;
        
		Serial_Start();
		
		Serial_Write_Byte(cmd);
		
		temp = Serial_Read_Byte();
		
		Serial_Stop();
		
		return temp;
		
	} 
	




	
	unsigned char Get_Secs(void) {
		
		unsigned char sec=0;
		
		
		sec = Read_Rtc_Data(0x81);
		 
		 //convert seconds from bcd to number 
		
		temp = sec;
		sec = ((temp&0x7F)>>4)*10 + (temp & 0x0F) ;
		
		return sec;	
		
		
	}
	
	
	unsigned char Get_Mins(void) {
		
		unsigned char min;
		
		
		min = Read_Rtc_Data(0x83);
		
		 temp = min;
		
		min = ((temp>>4)*10) + (temp & 0x0F);
		
		return min;
		
		}
				
	unsigned char* Get_Hours(void)
	{
		unsigned char hour;
					
		
		hour = Read_Rtc_Data(0x85);
		
		temp = hour;
		
				
		if(temp&0x80){     // check D7 for 12 hour mode
			 
			 rtc_hour[1] = 1;  // 12 hour flag
			if(temp&0x20)
				rtc_hour[2]=1;    //PM flag
			else rtc_hour[2]=2;	 // AM flag

		
                   
		hour = ((temp & 0x1F)>>4)*10 + (temp & 0x0F);  
			
		rtc_hour[0] = hour;
        		
		}
		
		else{
			
			
		hour = ((temp)>>4)*10 + (temp & 0x0F); 	
		    rtc_hour[0] = hour;
			rtc_hour[1] = 0; // 24 hour mode
			rtc_hour[2] = 0; //nothing 
			
		}
				
		return rtc_hour; 
	}
	
	
	
	
	unsigned char Get_Date(void) 
	{
		unsigned char date;
		temp=0;
		
		date = Read_Rtc_Data(0x87);
		
		temp = date;
		
		date = ((temp>>4)*10) + (temp & 0x0F);
		
		return date;
					
	}
	
	
	unsigned char Get_Month(void){
		
		unsigned char month;
		temp=0;
		
		month = Read_Rtc_Data(0x89);
		temp = month;
		
		month = ((temp>>4)*10) + (temp & 0x0F);
		
		return month;
				
	}
	
	
	unsigned char Get_Year(void) {
		unsigned char year;
		temp=0;
		
		year = Read_Rtc_Data(0x8D);
		temp = year;
		
		year = ((temp>>4)*10) + (temp & 0x0F); //?
		
		return year;
				
	}
	unsigned char Get_Day(void)  {
		
		unsigned char day;
		temp=0;
		
		day = Read_Rtc_Data(0x8B);
			
		return day;
		
		
	}


	







