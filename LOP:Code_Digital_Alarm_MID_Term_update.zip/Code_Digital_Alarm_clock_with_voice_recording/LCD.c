#include "Includes.h"

void ToggleEpinOfLCD(void)
{
	E = 1;                // Give a pulse on E pin
	delay_us(250);  // so that LCD can latch the
	E = 0;                // data from data bus
  delay_us(250); 	
}

void WriteDataToLCD(char t)
{
   RS = 1;             // This is data

   P2 &= 0x0F;		   // Make P2.4 to P2.7 zero
   P2 |= (t&0xF0);     // Write Upper nibble of data
   ToggleEpinOfLCD();  // Toggle E pin to send data 

   P2 &= 0x0F;		   // Make P2.4 to P2.7 zero
   P2 |= ((t<<4)&0xF0);// Write Lower nibble of data
   ToggleEpinOfLCD();  // Toggle E pin to send data 
}


void WriteCommandToLCD(int z)
{
   RS = 0;             // This is command

   P2 &= 0x0F;		   // Make P2.4 to P2.7 zero
   P2 |= (z&0xF0);     // Write Upper nibble of data
   ToggleEpinOfLCD();  // Toggle E pin to send data 

   P2 &= 0x0F;		   // Make P2.4 to P2.7 zero
   P2 |= ((z<<4)&0xF0);// Write Lower nibble of data
   ToggleEpinOfLCD();  // Toggle E pin to send data 
}

void InitLCD(void)
{
	RS = 0;		 	// Make pin zero
	E  = 0;			// Make Pin zero					

  ///////////// Reset process from datasheet /////////
     delay_ms(15);

	 P2 &= 0x0F;		   // Make P2.4 to P2.7 zero
	 P2 |= 0x30;    	   // Write 0x3
     ToggleEpinOfLCD();    // Toggle E pin to send data 

     delay_ms(5);

	 P2 &= 0x0F;		   // Make P2.4 to P2.7 zero
	 P2 |= 0x30;    	   // Write 0x3
     ToggleEpinOfLCD();    // Toggle E pin to send data 

     delay_us(150);
     delay_us(150);

	 P2 &= 0x0F;		   // Make P2.4 to P2.7 zero
	 P2 |= 0x30;    	   // Write 0x3
     ToggleEpinOfLCD();    // Toggle E pin to send data 

     delay_us(250);
     delay_us(250);
     delay_us(100);
	 
	 P2 &= 0x0F;		   // Make P2.4 to P2.7 zero
	 P2 |= 0x20;    	   // Write 0x2
     ToggleEpinOfLCD();    // Toggle E pin to send data 

	delay_us(250);
     delay_us(250);
     delay_us(100);
	 

  /////////////////////////////////////////////////////
   WriteCommandToLCD(0x28);    //function set
   WriteCommandToLCD(0x0c);    //display on,cursor off,blink off
   WriteCommandToLCD(0x01);    //clear display
   WriteCommandToLCD(0x06);    //entry mode, set increment
}



void ClearLCDScreen(void)       // Clear the Screen and return cursor to zero position
{
	WriteCommandToLCD(0x01);    // Clear the screen
	delay_ms(3);           // Delay for cursor to return at zero position
}


void WriteStringToLCD(const char *s)
{
	while(*s)	
		WriteDataToLCD(*s++); 
}


void DisplayTimeToLCD()   // Displays time in HH:MM:SS AM/PM format
{
	unsigned char temp = 0;
	unsigned char* rtc_hour;
	ClearLCDScreen();      // Move cursor to zero location and clear screen

//Display Hour
	
	rtc_hour = Get_Hours();
	temp = rtc_hour[0];        // 12 hour made right now
	WriteDataToLCD( (temp/10)+0x30 );
	WriteDataToLCD( (temp%10)+0x30 );
    
  
	//Display ':'
	WriteDataToLCD(':');

	//Display Minutes
	temp = Get_Mins();
	WriteDataToLCD( (temp/10)+0x30 );
	WriteDataToLCD( (temp%10)+0x30 );

	//Display ':'
	WriteDataToLCD(':');
	
	
  //Display Seconds
    temp = Get_Secs();
	WriteDataToLCD( (temp/10)+0x30 );
	WriteDataToLCD( (temp%10)+0x30 );	

	//Display Space
	WriteDataToLCD(' ');

	//Display AM/PM
	switch(rtc_hour[2])
	{
	case AM:	WriteStringToLCD("AM");	break;  //rtc_hour[2] = 2 for AM
	case PM:	WriteStringToLCD("PM");	break;  //rtc_hour[2] = 1 for PM
	default: WriteDataToLCD('H');	   break; 
	}
}



void DisplayDateOnLCD( )   // Displays Date in DD:MM:YY @ Day format
{  unsigned char temp = 0;
	WriteCommandToLCD(0xC0);      // Move cursor to second line

	// Display Date
	temp = Get_Date();
	WriteDataToLCD( (temp/10)+0x30 );
	WriteDataToLCD( (temp%10)+0x30 );

	//Display '/'
	WriteDataToLCD('/');

	//Display Month
	temp = Get_Month();
	WriteDataToLCD( (temp/10)+0x30 );
	WriteDataToLCD( (temp%10)+0x30 );

	//Display '/'
	WriteDataToLCD('/');

	//Display Year
	temp = Get_Year();
	WriteDataToLCD( (temp/10)+0x30 );
	WriteDataToLCD( (temp%10)+0x30 );

	//Display Space
	WriteDataToLCD(' ');

	// Display Day
	temp = Get_Day();
	switch(temp)
	{
	case Monday:		WriteStringToLCD("MON");	break;
	case Tuesday:		WriteStringToLCD("TUE");	break;
	case Wednesday:	WriteStringToLCD("WED");	break;
	case Thursday:		WriteStringToLCD("THU");	break;
	case Friday:		WriteStringToLCD("FRI");	break;
	case Saturday:		WriteStringToLCD("SAT");	break;
	case Sunday:		WriteStringToLCD("SUN");	break;

	default: WriteStringToLCD("???");	break;
	}
}


void DisplayAlarmToLCD(unsigned char Ahour, unsigned char Amin)   // Displays time in HH:MM:SS AM/PM format
{
	
	
	
	ClearLCDScreen();      // Move cursor to zero location and clear screen

//Display Alarm Hour
	
	
	
	WriteDataToLCD( (Ahour/10)+0x30 );
	WriteDataToLCD( (Ahour%10)+0x30 );
    
  
	//Display ':'
	WriteDataToLCD(':');

	//Display Alarm Minutes
	
	WriteDataToLCD( (Amin/10)+0x30 );
	WriteDataToLCD( (Amin%10)+0x30 );
	
}












