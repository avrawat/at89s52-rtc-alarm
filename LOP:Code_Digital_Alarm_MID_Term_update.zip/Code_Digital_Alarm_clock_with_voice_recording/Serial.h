#ifndef __SERIAL_H
#define __SERIAL_H
 
 
 #define Low  0
 #define High 1
sbit RESET = P2^0;    // RESET'
sbit SCL   = P2^1;    // Serial Clock
sbit SDA   = P2^2;    //I/O 


void delay_us(unsigned char); //u.c. 0-255
void delay_ms(unsigned char);
void Init_Serial(void);
void Serial_Start(void);
void Serial_Stop(void);
void Serial_Write_Byte(unsigned char);
unsigned char Serial_Read_Byte(void);


#endif
